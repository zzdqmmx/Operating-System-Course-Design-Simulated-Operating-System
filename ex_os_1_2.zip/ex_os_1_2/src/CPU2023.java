import javax.swing.*;
import java.awt.*;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Stack;

public class CPU2023 {
    /**CPU中的寄存器*/
    static int pc = 0;//程序计数器
    static int ir = 0;//指令寄存器
    static int psw = 0;//状态寄存器0开中断，1关中断
    private Clock_thread timer;//计时器
    public void setTimer(Clock_thread timer) {
        this.timer = timer;
    }
    private JTextArea textArea1;//日志可视化文本框
    public void setTextArea1(JTextArea textArea1){
        this.textArea1 = textArea1;
    }

    public void run(PCB pcb,Thread t) {
            try {
                    runCpu(pcb,t);
            } catch (IOException | InterruptedException e) {
                throw new RuntimeException(e);
            }

    }

    synchronized private void runCpu(PCB pcb,Thread t) throws IOException, InterruptedException {
        //pc为当前要执行的指令号，ir为指令种类
        switch (ir){
            case 0:
            case 1: {
                /*输出运行日志*/
                FileWriter fw = new FileWriter(Window.outPath, true);
                BufferedWriter bw = new BufferedWriter(fw);
                bw.write(timer.COUNTTIME + ":[运行进程:" + pcb.getProID() + "," + pc + "," + ir+","+pcb.getInstructionArr()[pc][2]+","+pcb.mmap.get(pcb.getInstructionArr()[pc][2])[0]+"]\r\n");
                textArea1.append(timer.COUNTTIME + ":[运行进程:" + pcb.getProID() + "," + pc + "," + ir+","+pcb.getInstructionArr()[pc][2]+","+pcb.mmap.get(pcb.getInstructionArr()[pc][2])[0]+"]\r\n");
                bw.close();
                fw.close();
                break;
            }//0型指令，计算,1型指令，函数调用
            case 2:{
                FileWriter fw = new FileWriter(Window.outPath, true);
                BufferedWriter bw = new BufferedWriter(fw);
                bw.write(timer.COUNTTIME + ":[运行进程:" + pcb.getProID() + "," + pc + "," + ir+","+pcb.getInstructionArr()[pc][2]+","+pcb.mmap.get(pcb.getInstructionArr()[pc][2])[0]+"]\r\n");
                textArea1.append(timer.COUNTTIME + ":[运行进程:" + pcb.getProID() + "," + pc + "," + ir+","+pcb.getInstructionArr()[pc][2]+","+pcb.mmap.get(pcb.getInstructionArr()[pc][2])[0]+"]\r\n");
                pcb.setPSW("block");
                Window.bqQueue1.add(Window.jobReadyQueue.poll());
                /*阻塞日志*/
                int i = 1;
                /*遍历就绪队列，查找到该进程所在队列中的位置*/
                for (PCB e : Window.bqQueue1) {
                    if (e.getProID() != pcb.getProID()) {
                        i++;
                    } else break;
                }
                pcb.setBqNum1(i);//设置在阻塞队列位置
                pcb.setBqTimes1(timer.COUNTTIME);//设置进入阻塞队列时间
                pcb.addbqList_1(pcb.getBqNum1(),pcb.getBqTimes1());//加入列表中
                /*记录阻塞队列状态信息*/
                Window.bqList1.add(pcb.getBqTimes1());
                Window.bqList1.add(pcb.getProID());
                /*输出日志*/
                bw.write(timer.COUNTTIME +":[阻塞进程:阻塞队列1,"+pcb.getProID()+"]\r\n");
                textArea1.append(timer.COUNTTIME +":[阻塞进程:阻塞队列1,"+pcb.getProID()+"]\r\n");
                bw.close();
                fw.close();
                InputBlock_thread in=new InputBlock_thread();
                /*日志版面设置*/
                in.setTextArea1(textArea1);
                in.setTimer(timer);
                in.start();
                break;
            }
            case 3:{
                FileWriter fw = new FileWriter(Window.outPath, true);
                BufferedWriter bw = new BufferedWriter(fw);
                bw.write(timer.COUNTTIME + ":[运行进程:" + pcb.getProID() + "," + pc + "," + ir+","+pcb.getInstructionArr()[pc][2]+","+pcb.mmap.get(pcb.getInstructionArr()[pc][2])[0]+"]\r\n");
                textArea1.append(timer.COUNTTIME + ":[运行进程:" + pcb.getProID() + "," + pc + "," + ir+","+pcb.getInstructionArr()[pc][2]+","+pcb.mmap.get(pcb.getInstructionArr()[pc][2])[0]+"]\r\n");
                pcb.setPSW("block");
                Window.bqQueue2.add(Window.jobReadyQueue.poll());
                /*阻塞日志*/
                int i = 1;
                /*遍历就绪队列，查找到该进程所在队列中的位置*/
                for (PCB e : Window.bqQueue2) {
                    if (e.getProID() != pcb.getProID()) {
                        i++;
                    } else break;
                }
                pcb.setBqNum2(i);//设置在阻塞队列位置
                pcb.setBqTimes2(timer.COUNTTIME);//设置进入阻塞队列时间
                pcb.addbqList_2(pcb.getBqNum2(),pcb.getBqTimes2());//加入列表中
                /*记录阻塞队列状态信息*/
                Window.bqList2.add(pcb.getBqTimes2());
                Window.bqList2.add(pcb.getProID());
                /*输出日志*/
                bw.write(timer.COUNTTIME +":[阻塞进程:阻塞队列2,"+pcb.getProID()+"]\r\n");
                textArea1.append(timer.COUNTTIME +":[阻塞进程:阻塞队列2,"+pcb.getProID()+"]\r\n");
                bw.close();
                fw.close();
                OutputBlock_thread out=new OutputBlock_thread();
                /*日志版面设置*/
                out.setTextArea1(textArea1);
                out.setTimer(timer);
                out.start();
                break;
            }
            case 4:{
                /*选题无该指令的操作*/
                break;
            }
            case 5:{
                FileWriter fw = new FileWriter(Window.outPath, true);
                BufferedWriter bw = new BufferedWriter(fw);
                bw.write(timer.COUNTTIME + ":[运行进程:" + pcb.getProID() + "," + pc + "," + ir+","+pcb.getInstructionArr()[pc][2]+","+pcb.mmap.get(pcb.getInstructionArr()[pc][2])[0]+"]\r\n");
                textArea1.append(timer.COUNTTIME + ":[运行进程:" + pcb.getProID() + "," + pc + "," + ir+","+pcb.getInstructionArr()[pc][2]+","+pcb.mmap.get(pcb.getInstructionArr()[pc][2])[0]+"]\r\n");
                pcb.setPSW("block");
                Window.bqQueue4.add(Window.jobReadyQueue.poll());
                /*阻塞日志*/
                int i = 1;
                /*遍历就绪队列，查找到该进程所在队列中的位置*/
                for (PCB e : Window.bqQueue4) {
                    if (e.getProID() != pcb.getProID()) {
                        i++;
                    } else break;
                }
                pcb.setBqNum4(i);//设置在阻塞队列位置
                pcb.setBqTimes4(timer.COUNTTIME);//设置进入阻塞队列时间
                pcb.addbqList_4(pcb.getBqNum4(),pcb.getBqTimes4());//加入列表中
                /*记录阻塞队列状态信息*/
                Window.bqList4.add(pcb.getBqTimes4());
                Window.bqList4.add(pcb.getProID());
                /*输出日志*/
                bw.write(timer.COUNTTIME +":[阻塞进程:阻塞队列4,"+pcb.getProID()+"]\r\n");
                textArea1.append(timer.COUNTTIME +":[阻塞进程:阻塞队列4,"+pcb.getProID()+"]\r\n");
                t.sleep(1000);//关中断，这期间不执行任何操作，等待读入完成
                //输出cpu空闲
                bw.write(timer.COUNTTIME+":[CPU空闲]\r\n");
                textArea1.append(timer.COUNTTIME+":[CPU空闲]\r\n");
                t.sleep(1000);//关中断，这期间不执行任何操作，等待读入完成
                //输出CPU空闲
                bw.write(timer.COUNTTIME+":[CPU空闲]\r\n");
                textArea1.append(timer.COUNTTIME+":[CPU空闲]\r\n");
                Window.jobReadyQueue.add(Window.bqQueue4.poll());//2秒后唤醒
                /*重新进入就绪队列日志*/
                bw.write(timer.COUNTTIME + ":[重新进入就绪队列:" + pcb.getProID() + "," + pcb.getInstrucNum() + "]\r\n");
                textArea1.append(timer.COUNTTIME + ":[重新进入就绪队列:" + pcb.getProID() + "," + pcb.getInstrucNum() + "]\r\n");
                bw.close();
                fw.close();
                // 修改加入队列时间和位置信息
                i = 1;
                /*遍历就绪队列，查找到该进程所在队列中的位置*/
                for (PCB e : Window.jobReadyQueue) {
                    if (e.getProID() != pcb.getProID()) {
                        i++;
                    } else break;
                }
                pcb.setRqNum(i);//在就绪队列位置
                pcb.setRqTimes(timer.COUNTTIME);//加入就绪队列时间
                pcb.addReadyList(pcb.getRqNum(), pcb.getRqTimes());//在列表中加入信息
                break;
            }
            case 6:{
                FileWriter fw = new FileWriter(Window.outPath, true);
                BufferedWriter bw = new BufferedWriter(fw);
                bw.write(timer.COUNTTIME + ":[运行进程:" + pcb.getProID() + "," + pc + "," + ir+","+pcb.getInstructionArr()[pc][2]+","+pcb.mmap.get(pcb.getInstructionArr()[pc][2])[0]+"]\r\n");
                textArea1.append(timer.COUNTTIME + ":[运行进程:" + pcb.getProID() + "," + pc + "," + ir+","+pcb.getInstructionArr()[pc][2]+","+pcb.mmap.get(pcb.getInstructionArr()[pc][2])[0]+"]\r\n");
                pcb.setPSW("block");
                Window.bqQueue5.add(Window.jobReadyQueue.poll());
                /*阻塞日志*/
                int i = 1;
                /*遍历就绪队列，查找到该进程所在队列中的位置*/
                for (PCB e : Window.bqQueue5) {
                    if (e.getProID() != pcb.getProID()) {
                        i++;
                    } else break;
                }
                pcb.setBqNum5(i);//设置在阻塞队列位置
                pcb.setBqTimes5(timer.COUNTTIME);//设置进入阻塞队列时间
                pcb.addbqList_5(pcb.getBqNum5(),pcb.getBqTimes5());//加入列表中
                /*记录阻塞队列状态信息*/
                Window.bqList5.add(pcb.getBqTimes5());
                Window.bqList5.add(pcb.getProID());
                /*输出日志*/
                bw.write(timer.COUNTTIME +":[阻塞进程:阻塞队列5,"+pcb.getProID()+"]\r\n");
                textArea1.append(timer.COUNTTIME +":[阻塞进程:阻塞队列5,"+pcb.getProID()+"]\r\n");
                t.sleep(1000);//关中断，这期间不执行任何操作，等待读入完成
                //输出cpu空闲
                bw.write(timer.COUNTTIME+":[CPU空闲]\r\n");
                textArea1.append(timer.COUNTTIME+":[CPU空闲]\r\n");
                t.sleep(1000);//关中断，这期间不执行任何操作，等待读入完成
                //输出CPU空闲
                bw.write(timer.COUNTTIME+":[CPU空闲]\r\n");
                textArea1.append(timer.COUNTTIME+":[CPU空闲]\r\n");
                Window.jobReadyQueue.add(Window.bqQueue5.poll());//2秒后唤醒
                /*进入就绪队列日志*/
                bw.write(timer.COUNTTIME + ":[重新进入就绪队列:" + pcb.getProID() + "," + pcb.getInstrucNum() + "]\r\n");
                textArea1.append(timer.COUNTTIME + ":[重新进入就绪队列:" + pcb.getProID() + "," + pcb.getInstrucNum() + "]\r\n");
                bw.close();
                fw.close();
                // 修改加入队列时间和位置信息
                i = 1;
                /*遍历就绪队列，查找到该进程所在队列中的位置*/
                for (PCB e : Window.jobReadyQueue) {
                    if (e.getProID() != pcb.getProID()) {
                        i++;
                    } else break;
                }
                pcb.setRqNum(i);//在就绪队列位置
                pcb.setRqTimes(timer.COUNTTIME);//加入就绪队列时间
                pcb.addReadyList(pcb.getRqNum(), pcb.getRqTimes());//在列表中加入信息
                break;
            }
        }
        pc++;
        pcb.setInstrucNum(pcb.getInstrucNum() - 1);//剩余指令数减1
        pcb.setStartTime(timer.COUNTTIME);//设置开始时间
        pcb.setRunningTimes(pcb.getRunningTimes() + 1);//设置总运行时间
        pcb.addRunTime(pcb.getStartTime(), pcb.getRunningTimes());//加入信息列表
    }

    /**进程调度类方法*/
    /*CPU 寄存器现场保护现场恢复*/
    static void CPU_PRO(Stack<Integer> st,PCB pcb){
        pcb.setPC(pc);//保存指令号
        pcb.setIR(ir);//保存指令种类号
        pcb.setPSW("ready");//进程就绪
        //st.push(pc);
        //st.push(ir);
    }
    /*CPU 寄存器现场恢复*/
    static void CPU_REC(Stack<Integer> st,PCB pcb,MMU mmu,JTextArea textArea1,Clock_thread timer) throws IOException {
        //ir=st.pop();
        //pc=st.pop();
        pc=pcb.getPC();//获取当前要执行的指令号
        ir=pcb.getInstructionArr()[pc-1][1];//获取当前要执行的指令种类号
        pcb.setPSW("run");//进程运行
        //地址变换
        mmu.PageTableCreate(pcb.mmap,pcb.getInstructionArr()[pc][2],pcb.blocks,timer,textArea1,pcb.getProID());
    }
}
