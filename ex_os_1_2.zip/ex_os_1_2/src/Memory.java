import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Memory {
    private static class Block {
        byte[] content;//一个块的空间
        boolean isUsed;//块是否被使用

        Block() {
            this.content = new byte[1024];
            this.isUsed = false;
        }//一个块1B
    }
    private ArrayList<Block> data;//整个内存空间
    int used;//已有的进程数
    /*初始化内存*/
    Memory() {
        //Block block = new Block();
        this.data = new ArrayList<Block>(16);//内存有16块
        for (int i = 0; i < 16; i++) {
            this.data.add(new Block());
        }
        used = 0;//已有的进程数
    }
    /*初始化进程的内存*/
    int procmeminit(PCB pcb) {
        if (used > 4) return -1;//内存满，返回-1，分配失败
        /*分配4个块*/
        int b1 = alloc();//申请块
        int b2 = alloc();
        int b3 = alloc();
        int b4 = alloc();
        //创建页表,键为页号，值为数组，数组中第一位为块号，第二位为是否已装入
        HashMap<Integer, int[]> mmap = new HashMap<Integer, int[]>();
        /*初始化页表内容*//*记录该进程的内存块*/
        if(b1!=-1){
            int[] arr = {b1,0};//b1初始化，未装入
            mmap.put(1, arr);//初始信息存入页表
            pcb.blocks[0] = b1;//块信息记录
        }
        if(b2!=-1){
            int[] arr = {b2,0};
            mmap.put(2, arr);
            pcb.blocks[1] = b2;
        }
        if(b3!=-1){
            int[] arr = {b3,0};
            mmap.put(3, arr);
            pcb.blocks[2] = b3;
        }
        if(b4!=-1){
            int[] arr = {b4,0};
            mmap.put(4, arr);
            pcb.blocks[3] = b4;
        }
        pcb.mmap = mmap;//页表记录在pcb中
        used++;//分配的进程数+1
        return 0;
    }
    /*块的分配*/
    int alloc() {
        for (int i = 0; i < 16; i++) {
            if (!this.data.get(i).isUsed) {
                this.data.get(i).isUsed = true;//该块被占用
                return i;//返回分配的块号
          }
        }
        return -1;  //返回-1分配失败
    }

    void free(int i) {
        this.data.get(i).isUsed = false;//释放内存
    }
}
