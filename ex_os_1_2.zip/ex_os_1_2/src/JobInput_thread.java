import javax.swing.*;
import java.awt.*;
import java.io.*;
public class JobInput_thread implements Runnable{
    private Thread t;
    private Clock_thread timer;//时钟计时器
    public void setTimer(Clock_thread timer) {
        this.timer = timer;
    }
    private int[][] jobArr;//临时作业数组
    public void setJobArr(int[][] jobArr) {
        this.jobArr = jobArr;
    }
    private JTextArea instructions;//指令文本读入
    public void setInstructions(JTextArea instructions){
        this.instructions = instructions;
    }
    private JTextArea textArea1;//日志输入
    public void setTextArea1(JTextArea textArea1){
        this.textArea1 = textArea1;
    }

    //作业请求硬件中断
    public void run() {
        /**读入作业至数组中*/
        File file =new File("input1\\jobs-input.txt");

        try {
            FileReader fis = new FileReader(file);
            BufferedReader in = new BufferedReader(fis);
            String s;
            int i = 0;
            while ((s=in.readLine())!=null&&s.length()>0){//按行读入
                String[] arr;
                arr=s.split(",");//分割字符串，去掉“,”
                for (int j = 0; j < 4; j++) {
                    jobArr[i][j]=Integer.parseInt(arr[j].trim());//字符串转为int存入数组
                }
                jobArr[i][4] = 0;//0表示未装入，防止重复装入
                i++;
            }
            in.close();
            fis.close();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        /**每十秒查询*/
        while (true){
            try {
                inquire(jobArr);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }
    synchronized private void inquire(int[][] jobArr) throws InterruptedException {
        try {
            //查询作业数组
            int i=0;
            while (jobArr[i][0]!=0 && i < jobArr.length){//从头开始看
                if (jobArr[i][2]<=timer.COUNTTIME && jobArr[i][4]==0)//作业未装入过且到申请时间
                {
                    //请求时间小于现在获取到的时间，说明有作业请求，加入作业后备队列
                    Window.jobBackQueue.add(jobArr[i][0]);
                    Window.askTimeForm.put(jobArr[i][0],timer.COUNTTIME);//记录进程的申请时间
                    /*日志书写和可视化显示*/
                    FileWriter fw = new FileWriter(Window.outPath,true);
                    BufferedWriter bw = new BufferedWriter(fw);
                    bw.write(timer.COUNTTIME+":[新增作业:"+jobArr[i][0]+"，"+jobArr[i][2]+"，"+jobArr[i][3]+"]\r\n");
                    textArea1.append(timer.COUNTTIME+":[新增作业:"+jobArr[i][0]+"，"+jobArr[i][2]+"，"+jobArr[i][3]+"]\r\n");
                    bw.close();
                    fw.close();
                    jobArr[i][4]=1;//作业已装入
                    //读入代码并保存在hashmap中
                    /*保存进程的代码*/
                    String inpath ="input1\\"+jobArr[i][0]+".txt";
                    FileReader fis =new FileReader(inpath);
                    BufferedReader in = new BufferedReader(fis);
                    int[][] instructionArr=new int[50][3];//分别保存指令号，指令类型和虚拟地址
                    String s;
                    int t=0;
                    while ((s=in.readLine())!=null&&s.length()>0){
                        String[] arr;
                        arr=s.split(",");//分割字符串，去掉“,”
                        for (int j = 0; j < 3; j++) {
                            instructionArr[t][j]=Integer.parseInt(arr[j].trim());//字符串转为int存入数组
                        }
                        t++;
                    }
                    in.close();
                    fis.close();
                    Window.codeForm.put(jobArr[i][0],instructionArr);//保存代码段
                }else if (jobArr[i][2]<=timer.COUNTTIME && jobArr[i][4]==2){//实时请求作业
                    //请求时间小于现在获取到的时间，说明有作业请求，加入作业后备队列
                    Window.jobBackQueue.add(jobArr[i][0]);
                    Window.askTimeForm.put(jobArr[i][0],timer.COUNTTIME);
                    /*日志书写和可视化显示*/
                    FileWriter fw = new FileWriter(Window.outPath,true);
                    BufferedWriter bw = new BufferedWriter(fw);
                    bw.write(timer.COUNTTIME+":[新增作业:"+jobArr[i][0]+"，"+jobArr[i][2]+"，"+jobArr[i][3]+"]\r\n");
                    textArea1.append(timer.COUNTTIME+":[新增作业:"+jobArr[i][0]+"，"+jobArr[i][2]+"，"+jobArr[i][3]+"]\r\n");
                    bw.close();
                    fw.close();
                    jobArr[i][4]=1;//已经装入过
                    //读入代码并保存在hashmap中
                    int[][] instructionArr=new int[50][3];
                    String s=instructions.getText();
                    String[] arr;
                    arr=s.split(",");//分割字符串，去掉“,”
                    int k=0;
                    for(int t=0;t< arr.length/3;t++)
                        for (int j = 0; j < 3; j++) {
                            instructionArr[t][j]=Integer.parseInt(arr[k].trim());//字符串转为int存入数组
                            k++;
                        }
                    Window.codeForm.put(jobArr[i][0],instructionArr);
                }
                i++;
            }
            } catch (IOException e) {
            throw new RuntimeException(e);
        }
        Thread.sleep(10000);//每十秒查询临时数组
    }
    public void start(){
        t=new Thread(this);
        if(t!=null){
            t.start();
        }
    }
}
