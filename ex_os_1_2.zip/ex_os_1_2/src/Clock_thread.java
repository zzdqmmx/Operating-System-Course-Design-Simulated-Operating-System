public class Clock_thread implements Runnable {
    private Thread t;
    public int COUNTTIME = 0;//从0开始计时
    @Override
    public void run() {
        while(true){
            setTime();
        }
    }
    public void start() {
        t = new Thread(this);
        if(t != null){
            t.start();
        }
    }
    synchronized private void setTime(){
        try {
            Thread.sleep(1000);
            COUNTTIME++;
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}
