import javax.swing.*;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Stack;

public class ProcessImage {
    /**作业进程映像*/
    /*创建进程映像*/
    public static void createProcess(int headjob,Clock_thread timer, JTextArea textArea1,int priority,Memory memory) throws IOException {
        PCB pcb = new PCB();//创建进程的pcb
        Stack<Integer> st = new Stack<>();//创建进程对应的栈
        int[][] instructionArr = Window.codeForm.get(headjob);//该进程的指令
        pcb.setInstructionArr(instructionArr);//绑定自己的代码
        pcb.createPcb(instructionArr,pcb,timer,headjob,priority);//创建pcb
        pcb.setSt(st);//绑定自己的栈
        pcb.setInTimes(timer.COUNTTIME);//设置进程创建时间
        /*分配内存*/
        int back=memory.procmeminit(pcb);
        /*比较优先级完成替换*/
        if(back==-1){
            PCB pcb1 =Window.jobReadyQueue.poll();
            PCB pcb2 =Window.jobReadyQueue.poll();
            PCB pcb3 =Window.jobReadyQueue.poll();
            PCB pcb4 =Window.jobReadyQueue.poll();
            Window.jobReadyQueue.add(pcb1);
            Window.jobReadyQueue.add(pcb2);
            Window.jobReadyQueue.add(pcb3);
            assert pcb4 != null;
            if(pcb4.getPriority()>pcb.getPriority()) {//新进程优先级较小
                Window.suspQueue.add(pcb);//分配内存失败时添加至挂起队列
                Window.jobReadyQueue.add(pcb4);
            }
            else {//新进程优先级较大
                /*释放优先级小的进程内存*/
                for (int i = 0; i < 4; i++) {
                    memory.free(pcb4.blocks[i]);
                }
                /*重新分配给该进程内存*/
                memory.procmeminit(pcb);
                Window.suspQueue.add(pcb4);//分配内存失败时添加至挂起队列
                /*分配新进程加入就绪队列*/
                Window.jobReadyQueue.add(pcb);
                /*输出创建进程日志*/
                FileWriter fw = new FileWriter(Window.outPath, true);
                BufferedWriter bw = new BufferedWriter(fw);
                bw.write(timer.COUNTTIME + ":[进入就绪队列:" + pcb.getProID() + "," + pcb.getInstrucNum() + "]\r\n");
                textArea1.append(timer.COUNTTIME + ":[进入就绪队列:" + pcb.getProID() + "," + pcb.getInstrucNum() + "]\r\n");
                bw.close();
                fw.close();
                // 修改加入队列时间和位置信息
                int i = 1;
                /*遍历就绪队列，查找到该进程所在队列中的位置*/
                for (PCB e : Window.jobReadyQueue) {
                    if (e.getProID() != pcb.getProID()) {
                        i++;
                    } else break;
                }
                pcb.setRqNum(i);//在就绪队列位置
                pcb.setRqTimes(timer.COUNTTIME);//加入就绪队列时间
                pcb.addReadyList(pcb.getRqNum(), pcb.getRqTimes());//在列表中加入信息
            }
        }else{
            /*分配成功加入就绪队列*/
            Window.jobReadyQueue.add(pcb);
            /*输出进入就绪队列进程日志*/
            FileWriter fw = new FileWriter(Window.outPath, true);
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(timer.COUNTTIME + ":[进入就绪队列:" + pcb.getProID() + "," + pcb.getInstrucNum() + "]\r\n");
            textArea1.append(timer.COUNTTIME + ":[进入就绪队列:" + pcb.getProID() + "," + pcb.getInstrucNum() + "]\r\n");
            bw.close();
            fw.close();
            // 修改加入队列时间和位置信息
            int i = 1;
            /*遍历就绪队列，查找到该进程所在队列中的位置*/
            for (PCB e : Window.jobReadyQueue) {
                if (e.getProID() != pcb.getProID()) {
                    i++;
                } else break;
            }
            pcb.setRqNum(i);//在就绪队列位置
            pcb.setRqTimes(timer.COUNTTIME);//加入就绪队列时间
            pcb.addReadyList(pcb.getRqNum(), pcb.getRqTimes());//在列表中加入信息
        }
        Window.addPcb(pcb);//系统pcb表加入pcb
    }
    public static void undoProcess(PCB pcb){
        //从相应队列中移除
        Window.jobReadyQueue.remove(pcb);
        //资源归还
        Window.pcbForm.remove(pcb.getProID());
    }

}
