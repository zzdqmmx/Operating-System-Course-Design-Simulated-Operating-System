public class PageInterruption_thread implements Runnable{
    @Override
    public void run() {

    }
    private void Page_In(){//页装入

    }
    private void Page_Out(){//页淘汰

    }
}
