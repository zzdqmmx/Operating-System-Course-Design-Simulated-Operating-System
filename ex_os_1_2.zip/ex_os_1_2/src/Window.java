import javax.swing.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.util.*;

public class Window {
    private JPanel panel1;//容器1
    private JPanel panelupon;//上界容器
    private JPanel paneldown;//下界容器
    private JButton button1;//添加实时作业按钮
    private JButton exitbutton;//退出按钮
    private JPanel panel;//容器
    private JPanel textPanel;//文本容器
    private JPanel jobpanel;//实时作业容器
    private JTextArea textArea1;//文本容器
    public JTextArea getTextArea1(){
        return this.textArea1;
    }//获取输入的作业指令

    private JLabel JobID;
    private JTextField textFieldJobID;//作业号
    private JLabel jLableIntime;
    private JLabel jLableInstrucNum;
    private JTextField textField1;//作业指令数
    private JLabel jLableInstructions;
    private JPanel instrutionAreaJpanel3;
    public JTextArea instructions;//作业指令
    public JTextField textField2;

    public JTextArea getInstructions(){
        return this.instructions;
    }//获取指令

    /**单击添加实时作业请求或退出*/
    public Window(int[][] jobArr,Clock_thread timer) {
        button1.addMouseListener(new MouseAdapter() {//单击读入作业中断
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                //单击中断
                int i = 0;
                while (jobArr[i][0]!=0 && i<jobArr.length)
                    i++;
                //找到空白数组添加作业信息
                jobArr[i][0]=Integer.parseInt(textFieldJobID.getText());//作业号
                jobArr[i][1]=Integer.parseInt(textField2.getText());//进程优先级
                jobArr[i][2]=timer.COUNTTIME;//申请时间
                jobArr[i][3]=Integer.parseInt(textField1.getText());//指令数
                jobArr[i][4]=2;//实时请求
            }
        });
        exitbutton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                System.exit(0);//关闭程序正常退出
            }
        });
    }
    /**全局变量及常量*/
    static int allTimes = 0;
    static Queue jobBackQueue = new LinkedList();//作业后备队列，保存ProID
    static PriorityQueue<PCB> jobReadyQueue = new PriorityQueue<PCB>();//作业就绪队列，保存优先级和ProID
    static PriorityQueue<PCB> bqQueue1 = new PriorityQueue<PCB>();//键盘输入阻塞队列，保存优先级和ProID
    static PriorityQueue<PCB> bqQueue2 = new PriorityQueue<PCB>();//屏幕显示阻塞队列，保存优先级和ProID
    static PriorityQueue<PCB> bqQueue4 = new PriorityQueue<PCB>();//磁盘读文件阻塞队列，保存优先级和ProID
    static PriorityQueue<PCB> bqQueue5= new PriorityQueue<PCB>();//磁盘写文件阻塞队列，保存优先级和ProID
    public static HashMap<Integer, int[][]> codeForm = new HashMap<>();//代码表，用于保存进程对应的代码
    public static HashMap<Integer, Integer> askTimeForm = new HashMap<>();//请求时间表，保存请求时间
    private static final int MAX_NUM_OF_PCB = 4;//系统PCB表最大值，即进程最大数量
    public static HashMap<Integer, PCB> pcbForm = new HashMap<>();//系统pcb表，用于保存要执行的进程
    //进程结束信息记录哈希表*1
    public static HashMap<Integer, int[]> pcbTime = new HashMap<Integer, int[]>();
    //阻塞队列总信息列表*4
    public static List<Integer> bqList1 = new ArrayList<>();
    public static List<Integer> bqList2 = new ArrayList<>();
    public static List<Integer> bqList4 = new ArrayList<>();
    public static List<Integer> bqList5 = new ArrayList<>();
    //页面替换列表
    public static List<Integer> pageList = new ArrayList<>();
    public static Queue<PCB> suspQueue = new LinkedList<>();//作业挂起队列，保存ProID
    public static void addPcb(PCB pcb){    //添加进程pcb
        pcbForm.put(pcb.getProID(),pcb);
    }

    public static String outPath = "output1\\ProcessResults-"+Window.allTimes+"-JTYX.txt";//文件输出路径
    /**主函数*/
    public static void main(String[] args) throws IOException {
        int[][] jobArr = new int[32][5];//临时数组保存作业
        Clock_thread timer = new Clock_thread();//时钟线程
        JobInput_thread JIT = new JobInput_thread();//作业请求线程
        ProcessScheduling_thread PST = new ProcessScheduling_thread();//进程调度线程
        Memory memory = new Memory();
        MMU mmu = new MMU();

        Window window = new Window(jobArr,timer);//窗体
        JFrame frame = new JFrame("Window");
        frame.setContentPane(window.panel1);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
        /*设置时钟*/
        JIT.setTimer(timer);
        PST.setTimer(timer);
        /*设置临时作业数组*/
        JIT.setJobArr(jobArr);
        PST.setJobArr(jobArr);
        JIT.setInstructions(window.getInstructions());//设置代码段
        /*传入文本框读入数据*/
        JIT.setTextArea1(window.getTextArea1());
        PST.setTextArea1(window.getTextArea1());
        /*设置内存*/
        PST.setMemory(memory);
        PST.setMmu(mmu);
        /*启动线程*/
        timer.start();
        JIT.start();
        PST.start();
    }
}
