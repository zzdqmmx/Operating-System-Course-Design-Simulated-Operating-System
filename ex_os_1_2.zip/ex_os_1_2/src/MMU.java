import javax.swing.*;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;

public class MMU {
    void PageTableCreate(HashMap<Integer,int[]> mmp, int L_Address, int[] blocks, Clock_thread timer, JTextArea textArea1,int ProID) throws IOException {
        if(!mmp.containsKey(L_Address)){
            int[] arr ={blocks[L_Address%4],1};
            mmp.put(L_Address,arr);//查询页表中是否已有该页的映射关系，如果没有就加入该记录
           }
        else if(mmp.containsKey(L_Address) && mmp.get(L_Address)[1]==0)
            mmp.get(L_Address)[1] = 1;//代表装入
        /*记录页面信息*/
        Window.pageList.add(timer.COUNTTIME);
        Window.pageList.add(ProID);
        /*地址变换日志输出*/
        FileWriter fw = new FileWriter(Window.outPath, true);
        BufferedWriter bw = new BufferedWriter(fw);
        bw.write(timer.COUNTTIME + ":[地址变换:"+L_Address +","+mmp.get(L_Address)[0]+"]\r\n");
        textArea1.append(timer.COUNTTIME +":[地址变换:"+L_Address +","+mmp.get(L_Address)[0]+"]\r\n");
        bw.close();
        fw.close();
    }
}
