import javax.swing.*;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Stack;

public class ProcessScheduling_thread implements Runnable {
    private Thread t;
    private Clock_thread timer;//时钟
    public void setTimer(Clock_thread timer) {
        this.timer = timer;
    }
    private JTextArea textArea1;//日志文本显示
    public void setTextArea1(JTextArea textArea1){
        this.textArea1 = textArea1;
    }
    private int[][] jobArr;//临时作业数组
    public void setJobArr(int[][] jobArr) {
        this.jobArr = jobArr;
    }
    private Memory memory;//内存
    public void setMemory(Memory memory) {
        this.memory = memory;
    }
    private MMU mmu;//地址变换类
    public void setMmu(MMU mmu) {
        this.mmu = mmu;
    }

    //时钟中断，作业请求和进程调度模块
    public void run() {
        CPU2023 cpu = new CPU2023();
        cpu.setTimer(timer);
        cpu.setTextArea1(textArea1);
        int Times = 3;//时间片3s
        //cpu.start();
        while (true){
            try {
                Times = CheckSchedulingTime(cpu,Times,jobArr);
            } catch (IOException | InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }
    synchronized private int CheckSchedulingTime(CPU2023 cpu,int Times,int[][] jobArr) throws IOException, InterruptedException {
        //时钟中断
        CPU2023.psw=0;//开中断
        /*创建进程*/
        while (!Window.jobBackQueue.isEmpty()) {//后备作业队列有作业
            int headjob= (int) Window.jobBackQueue.remove();//后备队列队头作业出队，要创建的进程号
            ProcessImage.createProcess(headjob,timer,textArea1,jobArr[headjob][1],memory);//创建进程映像
            /*输出创建进程日志*/
            FileWriter fw = new FileWriter(Window.outPath,true);
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(timer.COUNTTIME+":[创建进程:"+Window.pcbForm.get(headjob).getProID()+","+Window.pcbForm.get(headjob).blocks[0]+",静态页式分配"+"]\r\n");
            textArea1.append(timer.COUNTTIME+":[创建进程:"+Window.pcbForm.get(headjob).getProID()+","+Window.pcbForm.get(headjob).blocks[0]+",静态页式分配"+"]\r\n");
            bw.close();
            fw.close();
        }
        /*有进程*/
        if (!Window.jobReadyQueue.isEmpty()){
            PCB pcb = Window.jobReadyQueue.peek();//获取当前要运行的进程
            Stack<Integer> st = pcb.getSt();//获取进程栈
            //判断是否已完成
            while (pcb.getInstrucNum() <= 0) {//执行到最后一条指令
                pcb.setEndTimes(timer.COUNTTIME);//结束时间
                Window.allTimes+=pcb.getRunningTimes();//统计CPU工作时间
                //设置周转时间
                pcb.setTurnTimes(pcb.getEndTimes()-Window.askTimeForm.get(pcb.getProID()));//结束时间减去提交时间
                //保存结束进程信息
                int[] parr = {pcb.getEndTimes(),Window.askTimeForm.get(pcb.getProID()),pcb.getInTimes(),pcb.getRunningTimes()};
                Window.pcbTime.put(pcb.getProID(),parr);
                /*输出进程结束日志*/
                FileWriter fw = new FileWriter(Window.outPath,true);
                BufferedWriter bw = new BufferedWriter(fw);
                bw.write(timer.COUNTTIME+":[终止进程:"+pcb.getProID()+"]\r\n");
                textArea1.append(timer.COUNTTIME+":[终止进程:"+pcb.getProID()+"]\r\n");
                bw.close();
                fw.close();
                //删除进程映像
                ProcessImage.undoProcess(pcb);
                /*释放内存*/
                for (int i = 0; i < 4; i++) {
                    memory.free(pcb.blocks[i]);
                }
                /*从挂起队列中加入就绪队列，修改进程pcb信息*/
                if(!Window.suspQueue.isEmpty()){
                    PCB pcb1 = Window.suspQueue.remove();
                    Window.jobReadyQueue.add(pcb1);
                    /*输出重新进入就绪队列进程日志*/
                    fw = new FileWriter(Window.outPath, true);
                    bw = new BufferedWriter(fw);
                    bw.write(timer.COUNTTIME + ":[重新进入就绪队列:" + pcb1.getProID() + "," + pcb1.getInstrucNum() + "]\r\n");
                    textArea1.append(timer.COUNTTIME + ":[重新进入就绪队列:" + pcb1.getProID() + "," + pcb1.getInstrucNum() + "]\r\n");
                    bw.close();
                    fw.close();
                    // 修改加入队列时间和位置信息
                    int i = 1;
                    /*遍历就绪队列，查找到该进程所在队列中的位置*/
                    for (PCB e : Window.jobReadyQueue) {
                        if (e.getProID() != pcb1.getProID()) {
                            i++;
                        } else break;
                    }
                    pcb1.setRqNum(i);//在就绪队列位置
                    pcb1.setRqTimes(timer.COUNTTIME);//加入就绪队列时间
                    pcb1.addReadyList(pcb.getRqNum(), pcb.getRqTimes());//在列表中加入信息
                }
                /*获取新的进程pcb*/
                if (!Window.jobReadyQueue.isEmpty()){
                    pcb = Window.jobReadyQueue.peek();
                    st = pcb.getSt();
                }
                else break;
            }
            //进程调度
            if(Times <= 0)
            {
                /*静态优先级调度*/
                pcb = JTYX();
                Times = 3;//重设时间片
            }
            if (!Window.jobReadyQueue.isEmpty()){
                //现场恢复
                CPU2023.CPU_REC(pcb.getSt(), pcb,mmu,textArea1,timer);//重新获取
                if(pcb.getIR()==0 || pcb.getIR()==2 || pcb.getIR()==3 || pcb.getIR() ==4){//0型指令用时1秒，时间片-1
                    cpu.run(pcb,t);//运行指令
                    Times--;
                }
                else if(pcb.getIR()==1 && Times>=2){//1指令用时两秒，时间片-2
                    cpu.run(pcb,t);
                    Times-=2;
                    Thread.sleep(1000);//额外消耗一个时钟周期
                } else if (pcb.getIR()==5 || pcb.getIR()==6) {//5,6指令执行时需要关中断
                    CPU2023.psw=1;//关中断
                    cpu.run(pcb,t);
                    Times-=2;
                } else{//剩余时间不足2s，不执行任何指令
                    Times--;
                }
                CPU2023.CPU_PRO(st, pcb);//现场保护
            }
        } else if (Window.allTimes != 0 && Window.bqQueue1.isEmpty() && Window.bqQueue2.isEmpty() && Window.bqQueue4.isEmpty() && Window.bqQueue5.isEmpty()) {
            /*打印状态统计信息*/
            FileWriter fw = new FileWriter(Window.outPath,true);
            BufferedWriter bw = new BufferedWriter(fw);
            //进程结束信息
            for (Integer key : Window.pcbTime.keySet()) {
                bw.write(Window.pcbTime.get(key)[0] + ":[" + key + ":" + Window.pcbTime.get(key)[1] + "+"+Window.pcbTime.get(key)[2]+ "+"+Window.pcbTime.get(key)[3]+"]\r\n");
                textArea1.append(Window.pcbTime.get(key)[0] + ":[" + key + ":" + Window.pcbTime.get(key)[1] + "+"+Window.pcbTime.get(key)[2]+ "+"+Window.pcbTime.get(key)[3]+"]\r\n");
            }
            //队列统计信息
            bw.write( "BB1:[阻塞队列 1,键盘输入:"+Window.bqList1.toString()+"]\r\n");
            textArea1.append("BB1:[阻塞队列 1,键盘输入:"+Window.bqList1.toString()+"]\r\n");
            bw.write( "BB2:[阻塞队列 2,屏幕显示:"+Window.bqList2.toString()+"]\r\n");
            textArea1.append("BB2:[阻塞队列 2,屏幕显示:"+Window.bqList2.toString()+"]\r\n");
            bw.write( "BB4:[阻塞队列 4,磁盘读文件:"+Window.bqList4.toString()+"]\r\n");
            textArea1.append("BB4:[阻塞队列 4,磁盘读文件::"+Window.bqList4.toString()+"]\r\n");
            bw.write( "BB5:[阻塞队列 5,磁盘写文件:"+Window.bqList5.toString()+"]\r\n");
            textArea1.append("BB5:[阻塞队列 5,磁盘写文件:"+Window.bqList5.toString()+"]\r\n");
            //页表统计信息
            bw.write( "PPPP:[PageInterruption:"+Window.pageList.toString()+"]\r\n");
            textArea1.append("PPPP:[PageInterruption:"+Window.pageList.toString()+"]\r\n");
            File file = new File(Window.outPath);
            String s = "output1\\ProcessResults-"+Window.allTimes+"-JTYX.txt";
            file.renameTo(new File(s));
            Window.outPath = s;
            bw.close();
            fw.close();
        } else {/*没有进程*/
            FileWriter fw = new FileWriter(Window.outPath,true);
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(timer.COUNTTIME+":[CPU空闲]\r\n");
            textArea1.append(timer.COUNTTIME+":[CPU空闲]\r\n");
            bw.close();
            fw.close();
        }
        if(CPU2023.psw==0){
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
        return Times;
    }
    public void start(){
        t=new Thread(this);
        if(t!=null){
            t.start();
        }
    }
    /*时间片轮转调度算法*/
    public PCB LZ(PCB pcb,Clock_thread timer,int Times) throws IOException {
        if(Times==0 && !Window.jobReadyQueue.isEmpty()) {
            //时间片调度+打印输出
            PCB proid = Window.jobReadyQueue.poll();//出队
            /*调整在队列列表信息*/
            //adPcbReadyList(proid);
            Window.jobReadyQueue.add(proid);//入队
            pcb.setRqTimes(timer.COUNTTIME);//改变入队时间
            pcb.setRqNum(Window.jobReadyQueue.size());//改变入队位置
            pcb.addReadyList(pcb.getRqNum(),pcb.getRqTimes());//加入列表信息
            FileWriter fw = new FileWriter(Window.outPath,true);
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(timer.COUNTTIME+":[重新进入就绪队列："+pcb.getProID()+"，"+pcb.getInstrucNum()+"]\r\n");
            textArea1.append(timer.COUNTTIME+":[重新进入就绪队列："+pcb.getProID()+"，"+pcb.getInstrucNum()+"]\r\n");
            bw.close();
            fw.close();
            return Window.pcbForm.get(Window.jobReadyQueue.element().getProID());
        }else {
            return pcb;
        }
    }
    /*静态优先级调度算法*/
    public PCB JTYX() throws IOException {
        PCB pcb = Window.jobReadyQueue.poll();//出队
        Window.jobReadyQueue.add(pcb);//重新加入就绪队列
        /*输出进入就绪队列进程日志*/
        FileWriter fw = new FileWriter(Window.outPath, true);
        BufferedWriter bw = new BufferedWriter(fw);
        bw.write(timer.COUNTTIME + ":[重新进入就绪队列:" + pcb.getProID() + "," + pcb.getInstrucNum() + "]\r\n");
        textArea1.append(timer.COUNTTIME + ":[重新进入就绪队列:" + pcb.getProID() + "," + pcb.getInstrucNum() + "]\r\n");
        bw.close();
        fw.close();
        // 修改加入队列时间和位置信息
        int i = 1;
        /*遍历就绪队列，查找到该进程所在队列中的位置*/
        for (PCB e : Window.jobReadyQueue) {
            if (e.getProID() != pcb.getProID()) {
                i++;
            } else break;
        }
        pcb.setRqNum(i);//在就绪队列位置
        pcb.setRqTimes(timer.COUNTTIME);//加入就绪队列时间
        pcb.addReadyList(pcb.getRqNum(), pcb.getRqTimes());//在列表中加入信息
        return pcb;
    }
    /*调整在队列列表信息*/
    private void adPcbReadyList(PCB top){
        Window.jobReadyQueue.add(top);
        PCB flag= Window.jobReadyQueue.remove();
        PCB pcb = Window.pcbForm.get(flag);
        while(flag!= top){//遍历队列
            pcb.setRqTimes(pcb.getRqTimes());//改变入队时间
            pcb.setRqNum(pcb.getRqNum()-1);//改变入队位置
            pcb.addReadyList(pcb.getRqNum(),pcb.getRqTimes());//加入列表信息
            Window.jobReadyQueue.add(flag);
            //flag = (int) Window.jobReadyQueue.remove();
            pcb = Window.pcbForm.get(flag);
        }
    }
}
