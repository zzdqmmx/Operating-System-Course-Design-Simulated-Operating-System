import javax.swing.*;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class OutputBlock_thread implements Runnable{
    private Thread t;
    private JTextArea textArea1;//日志可视化文本框
    public void setTextArea1(JTextArea textArea1){
        this.textArea1 = textArea1;
    }
    private Clock_thread timer;//计时器
    public void setTimer(Clock_thread timer) {
        this.timer = timer;
    }
    @Override
    public void run() {
        try {
            weakUp();
        } catch (InterruptedException | IOException e) {
            throw new RuntimeException(e);
        }
    }
    private void weakUp() throws InterruptedException, IOException {
        Thread.sleep(2000);//两秒输入时间
        PCB pcb =  Window.bqQueue2.poll();//队头出队
        Window.jobReadyQueue.add(pcb);//进入就绪队列
        /*输出日志*/
        FileWriter fw = new FileWriter(Window.outPath, true);
        BufferedWriter bw = new BufferedWriter(fw);
        bw.write(timer.COUNTTIME + ":[重新进入就绪队列:" + pcb.getProID() + "," + pcb.getInstrucNum() + "]\r\n");
        textArea1.append(timer.COUNTTIME + ":[重新进入就绪队列:" + pcb.getProID() + "," + pcb.getInstrucNum() + "]\r\n");
        bw.close();
        fw.close();
        // 修改加入队列时间和位置信息
        int i = 1;
        /*遍历就绪队列，查找到该进程所在队列中的位置*/
        for (PCB e : Window.jobReadyQueue) {
            if (e.getProID() != pcb.getProID()) {
                i++;
            } else break;
        }
        pcb.setRqNum(i);//在就绪队列位置
        pcb.setRqTimes(timer.COUNTTIME);//加入就绪队列时间
        pcb.addReadyList(pcb.getRqNum(), pcb.getRqTimes());//在列表中加入信息
    }
    public void start() {
        t = new Thread(this);
        if(t != null){
            t.start();
        }
    }
}
