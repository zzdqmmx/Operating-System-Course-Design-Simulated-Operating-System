import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class memoryBuffer {
    /**内存缓冲区*/
    private class block {
        byte[] content;
        boolean isUsed;

        block() {
            this.content = new byte[1024];
        }
    }
    private ArrayList<memoryBuffer.block> data;
    int used;

    memoryBuffer() {
        this.data = new ArrayList<memoryBuffer.block>(4);
        used = 0;
    }

    int procmeminit(PCB pcb) {
        if (used > 4) return -1;
        int b1 = alloc();
        int b2 = alloc();
        int b3 = alloc();
        int b4 = alloc();
        HashMap<Integer, int[]> mmap = new HashMap<Integer, int[]>();
//        mmap.put(1, b1);
//        mmap.put(2, b2);
//        mmap.put(3, b3);
//        mmap.put(4, b4);
        pcb.mmap = mmap;
        return 0;
    }

    int alloc() {
        for (int i = 0; i < 4; i++) {
            if (!this.data.get(i).isUsed) {
                this.data.get(i).isUsed = true;
                return i;
            }
        }
        return -1;  // if return -1 this means that we don't have any free block to alloc.
    }

    void free(int i) {
        this.data.get(i).isUsed = false;
    }
}
