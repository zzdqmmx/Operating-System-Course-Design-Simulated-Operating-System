import java.util.*;

public class PCB implements Comparable<PCB>{
    public int[] blocks;//物理地址信息
    public HashMap<Integer, int[]> mmap;//进程的页表
    private Stack<Integer> st;          //保存该进程栈的信息
    public void setSt(Stack<Integer> st) {
        this.st = st;
    }
    public Stack<Integer> getSt() {
        return st;
    }

    private int[][] instructionArr;     //保存该进程对应的代码的信息，内涵指令的逻辑地址
    public void setInstructionArr(int[][] instructionArr) {
        this.instructionArr = instructionArr;
    }
    public int[][] getInstructionArr() {
        return instructionArr;
    }

    private int ProID;          //进程编号
    public void setProID(int proID) {
        ProID=proID;
    }
    public int getProID() {
        return ProID;
    }
    private int Priority;       //进程优先数
    public void setPriority(int priority) {
        Priority = priority;
    }
    public int getPriority() {
        return Priority;
    }
    private int InTimes;        //进程创建时间
    public void setInTimes(int inTimes) {
        InTimes = inTimes;
    }
    public int getInTimes() {
        return InTimes;
    }
    private int EndTimes;       //进程结束时间
    public void setEndTimes(int endTimes) {
        EndTimes = endTimes;
    }
    public int getEndTimes() {
        return EndTimes;
    }
    private String PSW;         //进程状态保存该进程当前状态：运行run、就绪ready、阻塞block
    public String getPSW() {
        return PSW;
    }
    public void setPSW(String psw) {
        this.PSW = psw;
    }//进程状态
    //进程运行时间列表
    private List<Integer> RunTime;
    public void setRunTime(List<Integer> runTime) {
        RunTime = runTime;
    }
    public void addRunTime(int startTime, int runningTimes){
        RunTime.add(startTime);
        RunTime.add(runningTimes);
    }
    public List<Integer> getRunTime() {
        return RunTime;
    }
    private int startTime;      //运行开始时刻
    public void setStartTime(int startTime) {
        this.startTime = startTime;
    }
    public int getStartTime() {
        return startTime;
    }
    private int runningTimes=0;   //运行用时
    public void setRunningTimes(int runningTimes) {
        this.runningTimes = runningTimes;
    }
    public int getRunningTimes() {
        return runningTimes;
    }
    private int TurnTimes;      //进程周转时间统计
    public void setTurnTimes(int turnTimes) {
        TurnTimes = turnTimes;
    }
    public int getTurnTimes() {
        return TurnTimes;
    }
    private int InstrucNum;     //进程剩余的指令数目
    public void setInstrucNum(int instrucNum) {
        InstrucNum = instrucNum;
    }
    public int getInstrucNum() {
        return InstrucNum;
    }
    private int PC;             //程序计数器信息
    public int getPC() {
        return PC;
    }
    public void setPC(int pc) {
        this.PC = pc;
    }
    private int IR;             //指令寄存器信息
    public void setIR(int IR) {
        this.IR = IR;
    }
    public int getIR() {
        return IR;
    }
    //在就绪队列信息列表
    private List<Integer> readyList;
    public void setReadyList(List<Integer> list){
        this.readyList = list;
    }
    public void addReadyList(int RqNum,int RqTimes){
        readyList.add(RqNum);
        readyList.add(RqTimes);
    }
    public List<Integer> getReadyList() {
        return readyList;
    }
    private int RqNum;          //位置编号
    public int getRqNum() {
        return RqNum;
    }
    public void setRqNum(int rqNum) {
        RqNum = rqNum;
    }
    private int RqTimes;        //进入就绪队列时间
    public int getRqTimes() {
        return RqTimes;
    }
    public void setRqTimes(int rqTimes) {
        RqTimes = rqTimes;
    }
    //在阻塞队列信息列表1
    private List<Integer> bqList_1;
    public void setBqList_1(List<Integer> bqList_1) {
        this.bqList_1 = bqList_1;
    }
    public void addbqList_1(int BqNum1,int BqTimes1){
        readyList.add(BqNum1);
        readyList.add(BqTimes1);
    }
    public List<Integer> getBqList_1(){
        return bqList_1;
    }
    private int BqNum1;   //在阻塞队列1位置编号
    public void setBqNum1(int bqNum1) {
        BqNum1 = bqNum1;
    }
    public int getBqNum1(){
        return BqNum1;
    }
    private int BqTimes1;//进入阻塞队列1时间
    public void setBqTimes1(int bqTimes1){
        BqTimes1 = bqTimes1;
    }
    public int getBqTimes1() {
        return BqTimes1;
    }
    //在阻塞队列信息列表2
    private List<Integer> bqList_2;
    public void setBqList_2(List<Integer> bqList_2) {
        this.bqList_2 = bqList_2;
    }
    public void addbqList_2(int BqNum2,int BqTimes2){
        readyList.add(BqNum2);
        readyList.add(BqTimes2);
    }
    public List<Integer> getBqList_2(){
        return bqList_2;
    }
    private int BqNum2;   //在阻塞队列2位置编号
    public void setBqNum2(int bqNum2) {
        BqNum2 = bqNum2;
    }
    public int getBqNum2(){
        return BqNum2;
    }
    private int BqTimes2;//进入阻塞队列2时间
    public void setBqTimes2(int bqTimes2){
        BqTimes2 = bqTimes2;
    }
    public int getBqTimes2() {
        return BqTimes2;
    }
    //在阻塞队列信息列表5
    private List<Integer> bqList_5;
    public void setBqList_5(List<Integer> bqList_5) {
        this.bqList_5 = bqList_5;
    }
    public void addbqList_5(int BqNum5,int BqTimes5){
        readyList.add(BqNum5);
        readyList.add(BqTimes5);
    }
    public List<Integer> getBqList_5(){
        return bqList_5;
    }
    private int BqNum5;   //在阻塞队列5位置编号
    public void setBqNum5(int bqNum5) {
        BqNum5 = bqNum5;
    }
    public int getBqNum5(){
        return BqNum5;
    }
    private int BqTimes5;//进入阻塞队列5时间
    public void setBqTimes5(int bqTimes5){
        BqTimes5 = bqTimes5;
    }
    public int getBqTimes5() {
        return BqTimes5;
    }
    //在阻塞队列信息列表4
    private List<Integer> bqList_4;
    public void setBqList_4(List<Integer> bqList_4) {
        this.bqList_4 = bqList_4;
    }
    public void addbqList_4(int BqNum4,int BqTimes4){
        readyList.add(BqNum4);
        readyList.add(BqTimes4);
    }
    public List<Integer> getBqList_4(){
        return bqList_4;
    }
    private int BqNum4;   //在阻塞队列4位置编号
    public void setBqNum4(int bqNum4) {
        BqNum4 = bqNum4;
    }
    public int getBqNum4(){
        return BqNum4;
    }
    private int BqTimes4;//进入阻塞队列4时间
    public void setBqTimes4(int bqTimes4){
        BqTimes4 = bqTimes4;
    }
    public int getBqTimes4() {
        return BqTimes4;
    }

    @Override
    public int compareTo(PCB o) {
        return this.Priority - o.Priority;//用优先级作为pcb的比较方法
    }
    //作业读取创建进程
    public void createPcb(int[][] instructionArr, PCB pcb, Clock_thread timer,int proID,int priority) {
        //设置pcb内容
        pcb.blocks = new int[4];//初始化内存物理块表
        pcb.mmap = new HashMap<>();//初始化地址变换表
        pcb.setProID(proID);//设置进程标识符
        int instrucNum =0;//统计指令数
        while (instructionArr[instrucNum][0]!=0)
            instrucNum++;
        pcb.setInstrucNum(instrucNum);//设定指令数量
        pcb.setInTimes(timer.COUNTTIME);//设定进程创建时间
        pcb.setPriority(priority);//设定进程优先级
        pcb.setPSW("ready");
        pcb.setIR(instructionArr[0][1]);
        pcb.setPC(instructionArr[0][0]);
        pcb.setReadyList(new ArrayList<>());
        pcb.setRunTime(new ArrayList<>());
    }
}
