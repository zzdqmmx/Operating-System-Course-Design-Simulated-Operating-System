import java.util.ArrayList;

public class fileBuffer {
    /**硬盘交换区*/
    private class block {
        byte[] content;
        boolean isUsed;

        block() {
            this.content = new byte[1024];
        }
    }
    private ArrayList<fileBuffer.block> data;
    int used;

    fileBuffer() {
        this.data = new ArrayList<fileBuffer.block>(16);
        used = 0;
    }
    //分配
    int alloc() {
        for (int i = 0; i < 16; i++) {
            if (!this.data.get(i).isUsed) {
                this.data.get(i).isUsed = true;
                //创建文件存入块

                return i;
            }
        }
        return -1;  // if return -1 this means that we don't have any free block to alloc.
    }
    //释放
    void free(int i) {
        this.data.get(i).isUsed = false;
    }
}
